# College Attendance System

## Features
- Add Students and Subjects
- Mark Attendance for students
- Store data using SQLite
- Simple Web Interface using Flask

## Setup Instructions
1. Clone Repository
2. Create Virtual Environment and activate it
3. Install Dependencies: `pip install -r requirements.txt`
4. Run the App: `python app.py`